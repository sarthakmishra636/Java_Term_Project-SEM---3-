-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 14, 2023 at 01:12 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `FilersRecord`
--

-- --------------------------------------------------------

--
-- Table structure for table `TaxFilers`
--

CREATE TABLE `TaxFilers` (
  `FilerID` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `AnnualIncome` double NOT NULL,
  `Expenses` double NOT NULL,
  `TaxYear` int(4) NOT NULL,
  `DateFiled` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `TaxFilers`
--

INSERT INTO `TaxFilers` (`FilerID`, `Name`, `Contact`, `AnnualIncome`, `Expenses`, `TaxYear`, `DateFiled`) VALUES
(103, 'Anirudh Pathak', 'pathak@yahoo.com', 74000, 2000, 2021, '2023-04-12'),
(105, 'Alex Smith', 'alex@example.com', 75000, 20000, 2022, '2023-04-11'),
(110, 'Bibek', '647-997-4883', 75000, 20000, 2022, '2023-04-12'),
(111, 'Leo', 'leo@gmail.com', 98000, 5000, 2022, '2023-04-05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `TaxFilers`
--
ALTER TABLE `TaxFilers`
  ADD PRIMARY KEY (`FilerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
