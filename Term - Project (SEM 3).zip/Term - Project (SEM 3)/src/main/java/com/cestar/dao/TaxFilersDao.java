package com.cestar.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cestar.model.Tax_Filers;

public class TaxFilersDao {

	public Connection getConnection() {

		Connection con = null;

		String url = "jdbc:mysql://localhost:3306/FilersRecord";

		String user = "root";

		String pwd = "";

		try {

			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection(url, user, pwd);

			System.out.println("Connection is established Successfully");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;

	}

	public List<Tax_Filers> read() {

		List<Tax_Filers> TaxFilers = new ArrayList<>();

		String sql = "select * from TaxFilers";

		Connection con = getConnection();

		try {

			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				Tax_Filers filer = new Tax_Filers(rs.getInt("FilerID"), rs.getString("Name"), rs.getString("Contact"),
						rs.getDouble("AnnualIncome"), rs.getDouble("Expenses"), rs.getInt("TaxYear"),
						rs.getDate("DateFiled"));

				TaxFilers.add(filer);
			}

			System.out.println(TaxFilers);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return TaxFilers;

	}

	public int insert(Tax_Filers newFilerInsert) {

		int status = 0;

		String sql = "insert into TaxFilers (FilerID,Name,Contact,AnnualIncome,Expenses,TaxYear,DateFiled) values (?, ? , ? , ? , ?, ?, ?)";

		Connection con = getConnection();

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, newFilerInsert.getFilerID());

			pstmt.setString(2, newFilerInsert.getName());

			pstmt.setString(3, newFilerInsert.getContact());

			pstmt.setDouble(4, newFilerInsert.getAnnualIncome());

			pstmt.setDouble(5, newFilerInsert.getExpenses());

			pstmt.setInt(6, newFilerInsert.getTaxYear());

			pstmt.setDate(7, newFilerInsert.getDateFiled());

			status = pstmt.executeUpdate();

			if (status > 0) {

				System.out.println("Record Inserted Successfully!!!");

				read();
			} else {
				System.out.println("Some Error Occured Try Again Please!!!");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;

	}

	public List<Tax_Filers> getRecById(int id_to_getRecord) {

		List<Tax_Filers> TaxFilers = new ArrayList<>();
		
		Tax_Filers filer = null;

		Connection con = getConnection();

		String sql = "select * from TaxFilers where FilerID = ?";

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id_to_getRecord);

			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				filer = new Tax_Filers(rs.getInt("FilerID"), rs.getString("Name"), rs.getString("Contact"),
						rs.getDouble("AnnualIncome"), rs.getDouble("Expenses"), rs.getInt("TaxYear"),
						rs.getDate("DateFiled"));
				TaxFilers.add(filer);
			}

			System.out.println(filer);

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return TaxFilers;

	}
	
	public Tax_Filers getRecByIdForUpdate(int id_to_getRecord) {
		
		
		Tax_Filers filer = null;

		Connection con = getConnection();

		String sql = "select * from TaxFilers where FilerID = ?";

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id_to_getRecord);

			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				filer = new Tax_Filers(rs.getInt("FilerID"), rs.getString("Name"), rs.getString("Contact"),
						rs.getDouble("AnnualIncome"), rs.getDouble("Expenses"), rs.getInt("TaxYear"),
						rs.getDate("DateFiled"));
				
			}

			System.out.println(filer);

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return filer;

	}


	public void updateById(int curr_id, Tax_Filers updatedTaxFiler) {

		Connection con = getConnection();

		String sql = "update TaxFilers set FilerID=? ,Name=? ,Contact=?,AnnualIncome=?,Expenses=?,TaxYear=?, DateFiled=? where FilerID= ?";

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, updatedTaxFiler.getFilerID());

			pstmt.setString(2, updatedTaxFiler.getName());

			pstmt.setString(3, updatedTaxFiler.getContact());

			pstmt.setDouble(4, updatedTaxFiler.getAnnualIncome());

			pstmt.setDouble(5, updatedTaxFiler.getExpenses());

			pstmt.setInt(6, updatedTaxFiler.getTaxYear());

			pstmt.setDate(7, updatedTaxFiler.getDateFiled());
			
			pstmt.setInt(8, updatedTaxFiler.getFilerID());

			int status = pstmt.executeUpdate();

			if (status > 0) {

				System.out.println("Record Updated Successfully");
				read();
			} else {
				System.out.println("Try Again Please!!!");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public void delete(int id_to_deleteRec) {

		Connection con = getConnection();

		String sql = "delete from TaxFilers where FilerID = ?";

		try {

			PreparedStatement pstmt = con.prepareStatement(sql);

			pstmt.setInt(1, id_to_deleteRec);

			int status = pstmt.executeUpdate();

			if (status > 0) {

				System.out.println("Record Deleted Successfully");
				read();
			} else {
				System.out.println("Try again please!!!");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
