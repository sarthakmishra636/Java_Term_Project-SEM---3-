package com.cestar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cestar.dao.TaxFilersDao;
import com.cestar.model.Tax_Filers;


/**
 * Servlet implementation class Controller
 */
@WebServlet("/")
public class TaxFilersController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public TaxFilersController() {
		super();
		// TODO Auto-generated constructor stub
	}

	TaxFilersDao dao = new TaxFilersDao();

	Tax_Filers client = new Tax_Filers();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();

		response.setContentType("text/html");

		String url = request.getServletPath();

		switch (url) {

		case "/insert": {

			insert(request, response);

			break;
		}

		case "/edit": {

			edit(request, response);
			break;
		}

		case "/update": {
			update(request, response);
			break;
		}
		case "/display": {

			display(request, response);
			break;
		}
		case "/displayById": {

			displayById(request, response);
			break;
		}

		case "/delete": {

			delete(request, response);
			break;
		}

		default: {

			out.print("<h1 style='color:green; text-align:center;'>Please Use a Valid Url !!!</h1>");
		}

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	protected void insert(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		int filerId = Integer.parseInt(request.getParameter("filerId"));

		String name = request.getParameter("name");

		String contact = request.getParameter("contact");

		Double annualIncome = Double.parseDouble(request.getParameter("annualIncome"));

		Double expenses = Double.parseDouble(request.getParameter("expenses"));

		int taxYear = Integer.parseInt(request.getParameter("taxYear"));

		Date dateFiled = Date.valueOf(request.getParameter("dateFiled"));

		request.setAttribute("errorMessage", null);

		Tax_Filers taxFiler = dao.getRecByIdForUpdate(filerId);

		if (taxFiler != null) {
			System.out.println(" Tax Filer with the ID " +filerId+ " already present ");
			request.setAttribute("errorMessage", "Tax Filer with the ID " +filerId+ " already present");

			RequestDispatcher rd = request.getRequestDispatcher("insert.jsp");

			rd.forward(request, response);
			return;
		}

		Tax_Filers newTaxFiler = new Tax_Filers(filerId, name, contact, annualIncome, expenses, taxYear, dateFiled);

		dao.insert(newTaxFiler);

		display(request, response);

	}

	protected void display(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		List<Tax_Filers> taxFilers = new ArrayList<>();

		taxFilers = dao.read();

		HttpSession session = request.getSession();

		session.setAttribute("listOfTaxFilers", taxFilers);

		RequestDispatcher rd = request.getRequestDispatcher("view.jsp");

		rd.forward(request, response);

	}

	protected void displayById(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		System.out.println("In displayById");

		int filerId = Integer.parseInt(request.getParameter("filerId"));

		List<Tax_Filers> taxFilers = new ArrayList<>();

		taxFilers = dao.getRecById(filerId);

		HttpSession session = request.getSession();

		session.setAttribute("listOfTaxFilers", taxFilers);

		RequestDispatcher rd = request.getRequestDispatcher("view.jsp");

		rd.forward(request, response);

	}

	protected void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");

		int id_to_edit_rec = Integer.parseInt(request.getParameter("filerId"));

		Tax_Filers editFiler = dao.getRecByIdForUpdate(id_to_edit_rec);

		HttpSession session = request.getSession();

		session.setAttribute("editFilerId", editFiler);

		RequestDispatcher rd = request.getRequestDispatcher("edit.jsp");

		rd.forward(request, response);

	}

	protected void update(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		int filerId = Integer.parseInt(request.getParameter("filerId"));

		String name = request.getParameter("name");

		String contact = request.getParameter("con");

		Double annualIncome = Double.parseDouble(request.getParameter("annualIncome"));

		Double expenses = Double.parseDouble(request.getParameter("expenses"));

		int taxYear = Integer.parseInt(request.getParameter("taxYear"));

		Date dateFiled = Date.valueOf(request.getParameter("dateFiled"));

		Tax_Filers updatedRecord = new Tax_Filers(filerId, name, contact, annualIncome, expenses, taxYear, dateFiled);

		HttpSession session = request.getSession();

		int oldId = (int) session.getAttribute("filerId");
		
		request.setAttribute("errorMessage", null);

		Tax_Filers taxFiler = dao.getRecByIdForUpdate(filerId);

		if (taxFiler == null) {
			System.out.println(" Unable to find Tax Filer with the ID " +filerId);
			request.setAttribute("errorMessage", "Unable to find Tax Filer with the ID " +filerId);

			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");

			rd.forward(request, response);
			return;
		}


		dao.updateById(oldId, updatedRecord);

		display(request, response);
	}

	protected void delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		int deleteId = Integer.parseInt(request.getParameter("filerId"));
		
		request.setAttribute("errorMessage", null);

		Tax_Filers taxFiler = dao.getRecByIdForUpdate(deleteId);

		if (taxFiler == null) {
			System.out.println(" Unable to find Tax Filer with the ID " +deleteId);
			request.setAttribute("errorMessage", "Unable to find Tax Filer with the ID " +deleteId);

			RequestDispatcher rd = request.getRequestDispatcher("delete.jsp");

			rd.forward(request, response);
			return;
		}


		dao.delete(deleteId);

		display(request, response);

	}

}
