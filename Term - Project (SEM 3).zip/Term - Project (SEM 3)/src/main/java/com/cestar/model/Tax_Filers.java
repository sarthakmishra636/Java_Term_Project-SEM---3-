package com.cestar.model;

import java.sql.Date;

public class Tax_Filers {
	private int FilerID;
	private String Name;
	private String Contact;
	private double AnnualIncome;
	private double Expenses;
	private int TaxYear;
	private Date DateFiled;

	@Override
	public String toString() {
		return "Tax_Filers [FilerID=" + FilerID + ", Name=" + Name + ", Contact=" + Contact + ", AnnualIncome="
				+ AnnualIncome + ", Expenses=" + Expenses + ", TaxYear=" + TaxYear + ", DateFiled=" + DateFiled + "]";
	}

	public Tax_Filers() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tax_Filers(int filerID, String name, String contact, double annualIncome, double expenses, int taxYear,
			Date dateFiled) {
		super();
		FilerID = filerID;
		Name = name;
		Contact = contact;
		AnnualIncome = annualIncome;
		Expenses = expenses;
		TaxYear = taxYear;
		DateFiled = dateFiled;
	}

	public int getFilerID() {
		return FilerID;
	}

	public void setFilerID(int filerID) {
		FilerID = filerID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getContact() {
		return Contact;
	}

	public void setContact(String contact) {
		Contact = contact;
	}

	public double getAnnualIncome() {
		return AnnualIncome;
	}

	public void setAnnualIncome(double annualIncome) {
		AnnualIncome = annualIncome;
	}

	public double getExpenses() {
		return Expenses;
	}

	public void setExpenses(double expenses) {
		Expenses = expenses;
	}

	public int getTaxYear() {
		return TaxYear;
	}

	public void setTaxYear(int taxYear) {
		TaxYear = taxYear;
	}

	public Date getDateFiled() {
		return DateFiled;
	}

	public void setDateFiled(Date dateFiled) {
		DateFiled = dateFiled;
	}

}
